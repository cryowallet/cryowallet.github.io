(function (exports) {
  var Bitcoin = exports;
})(
  'object' === typeof module ? module.exports : (window.Bitcoin = {})
);
