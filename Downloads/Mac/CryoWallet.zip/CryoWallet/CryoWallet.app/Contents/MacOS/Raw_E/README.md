I'm a wallet Jim, but not as you know it.

CryoWallet is a deterministic wallet. Your passphrase is turned into a number which is turned into Bitcoin Addresses. Addresses are identifiers you use to receive or send bitcoins to another person. With us your passphrase literally IS your wallet access and backup.

I'm a zero footprint wallet.

We don't store your Bitcoins or your private-keys on our servers, they exist only in your browser memory, and no trace is left on your device once you logout of a session. This way neither ourselves or any hackers can get at your bitcoins via our servers OR via your computer. 

I'm colder than cold storage.

Traditional 'cold storage' means storing coins offline or on a device. If you lose that device your stash goes too. Now you can safely store bitcoins without fear of unscrupulous exchanges. I'm non-device specific cold storage, so you can always access your wallet, from any device. 

Your passphrase is your wallet.

Your passphrase is turned into a 128bit key which is then stretched into 10 bitcoin addresses. According to "how big is your haystack?" Our passphrases would take trillions of centuries to break under a massive cracking scenario.

Our passphrases are also compatible with Brainwallet.org and Electrum Wallets, so even if this site goes down you'll still have access to your funds.

Cryowallet is Open Source.

Source code is available on Github. Feel free to fork and make your own wallet implementations.

All commits and changes are open for peer review and the site is deployed directly from the repository.